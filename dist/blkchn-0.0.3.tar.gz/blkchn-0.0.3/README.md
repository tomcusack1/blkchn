# Blkchn

A Python implementation of a Blockchain data structure.

# Installation

`pip install blkchn`
