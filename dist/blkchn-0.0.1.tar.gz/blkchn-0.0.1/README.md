# Blockchain

A Python implementation of a Blockchain data structure.

# Installation

Create a new Conda environment

`conda create -n blkchn`

`python setup.py install develop`
